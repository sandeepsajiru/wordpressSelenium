TESSERACT
===
TESSERACT is a 100% free wordpress theme that allow you to make a beautiful website. 



= Features =

Navigation

We focused most of our effort on the footer and header navigation to allow you to add buttons, change colors and be responsive.




== Credits ==

* Tesseract was based on Underscores http://underscores.me/ - (C) 2012-2014 Automattic, Inc. - [GNU General Public License v2 or later]
* /fonts/ http://typicons.com/ - (C) 2014 Stephen Hutchings - [SIL Open Font License]
